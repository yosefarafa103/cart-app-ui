export default function ErrorComponent() {
    return (
        <div>ErrorComponent</div>
    )
}
