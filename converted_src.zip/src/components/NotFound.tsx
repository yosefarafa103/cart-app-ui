import React from 'react'

export default function NotFound() {
    return (
        <div className='text-[4vw] max-sm:text-[30px] text-red-500 font-bold min-h-[90vh] flex items-center justify-center'>Hmm .. NotFound This Product!</div>
    )
}
