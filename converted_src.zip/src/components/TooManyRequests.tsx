function TooManyRequests() {
  return (
    <div className="min-h-screen flex items-center justify-center">
      <h2 className="font-bold text-center text-[40px] leading-[1]">
        Too Many Requests! Try Again Later
      </h2>
    </div>
  );
}
export default TooManyRequests;
